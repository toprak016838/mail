# vim /root/madmaxcontrol.sh
# aşağıdaki değişkenleri kendi setupınıza göre değiştirebilirsiniz.
################### madmaxcontrol.sh kodu başlıyor ###############################
#!/bin/bash
while [ true ]
 do 
sleep 200
echo "Basladi"


export PATH=$PATH:/usr/local/bin
SERVICE="chia_plot"
TMP_FOLDER="/root/temp/"
PLOT_FOLDER="/root/plt/"
PLOTER_FOLDER="/root/chia-plotter"
#public pool key
#PPK="xxxx"
#farmer pool key
#FPK="xxxx"

ALLOWED_PLOT_COUNT="2" #izin verilen max plot sayısı

SERVICE_PID=$(pgrep -x "$SERVICE")
PLOT_COUNT=$(find "$PLOT_FOLDER" -maxdepth 1 -type f -name '*.plot' | wc -l)
TMP_COUNT=$(find "$TMP_FOLDER" -maxdepth 1 -type f -name '*.tmp' | wc -l)

if [ ! -z $SERVICE_PID ]
then
    echo "$SERVICE çalışıyor"
    SERVICE_STATUS=$(ps -o s= -p $SERVICE_PID)
    echo "$SERVICE status: $SERVICE_STATUS"
    echo "plot sayısı: $PLOT_COUNT"
    if [ $SERVICE_STATUS == "S" ]
    then
        if [ $PLOT_COUNT -gt $ALLOWED_PLOT_COUNT ]
        then
            #servisi donduralım
            kill -SIGSTOP $SERVICE_PID
            echo "$SERVICE donduruldu"

        else
            #servis çalışmaya devam etsin
            echo "$SERVICE çalışmaya devam ediyor"
        fi
    else
        if [ $SERVICE_STATUS == "T" ] 
        then
            if [ $PLOT_COUNT -gt $ALLOWED_PLOT_COUNT ]
            then
                #izin verilenden fazla plot var
                echo "$SERVICE beklemeye devam ediyor"
            else
                #servisi devam ettirelim
                kill -SIGCONT $SERVICE_PID
                echo "$SERVICE devam ettiriliyor"
            fi
        fi
    fi
else
    echo "$SERVICE çalışmıyor"
    if [ $TMP_COUNT -gt 1 ] ; then
        #tempte dosyalar var önceki yarım kalan plottan, silelim
        echo "$TMP_FOLDER içi boşaltılıyor"
        rm "$TMP_FOLDER"*
    else
        echo "temp folder boşaltıldı"
    fi

    if [ $PLOT_COUNT -gt $ALLOWED_PLOT_COUNT ] ; then
        #zaten izin verdiğimiz kadar plot var, bekleyelim biraz boşalsın buralar
        echo "$ALLOWED_PLOT_COUNT plot var, daha calistirmiyoruz" 
    else
        #izin verilenden az plot var
        #plotter dizinine gidelim
        #cd $PLOTER_FOLDER
        # minerı çalıştıralım
        echo "madmax screen ile başlatılıyor"
        screen -dmS plot bash -c 'bash x.sh'
    fi
fi

 
done

################### madmaxcontrol.sh kodu bitiyor ###############################
# madmaxcontrol.sh ı çalıştırılabilir yapalım
# chmod u+x madmaxcontrol.sh
# crontab e ekleyelim 10 dk da bir çalışsın
# crontab -e
# */10 * * * * /root/madmaxcontrol.sh
# crontab restart
# sudo /etc/init.d/cron restart
#chia_plot (madmax) kapanmış ise:
#   temp klasorunde bi önceki üretimden kalan dosyaları siliyor
#   plot dizinini kontrol edip izin verilen max plot sayısından fazla plot yok ise
#       plotterı screen ile arkaplanda girdiğiniz parametreler ile başlatıyor
#   plot dizinini kontrol edip izin verilen max plot sayısından fazla plot var ise
#       plotterı çalıştırmıyor
#
#chia_plot (madmax) çalışıyor ise:
#   plotter dondurulmamışsa
#       plot dizininde izin verilenden fazla plot var ise
#           plotterı donduruyor
#       plot dizininde izin verilenden fazla plot yok ise
#           eğer plotter dondurulmuş ise
#               plotterı devam ettiriyor
#           eğer plotter çalışıyor ise
#               hiç birşey yapmıyor
#   plotter dondurulmuş ise
#       plot dizininde izin verilenden fazla plot var ise
#           hiçbirşey yapmıyor
#       plot dizininde izin verilenden fazla plot yok ise
#           plotterı devam ettiriyor   
#           